

%------------------------Copyright-----------------------------------
% Copyright (c) Apache License 2.0
% This is made for paper ' '
% You are free to use this for research purpose.
% All publications which use this should acknowledge of 
% " "
% Anny question,connect sun_chang@zju.edu.cn or sunchang0420@163.com
%--------------------------------------------------------------------

%-------------------reference----------------------------------------
%openExample('nnet/TrainNetworkWithMultipleOutputsExample')
%openExample('nnet/TrainNetworkOnImageAndFeatureDataExample')
%openExample('nnet/ClassifyImageUsingGoogLeNetExample')
%--------------------------------------------------------------------



%% inital
clear
clc

%% get txt data
data=xlsread('F:\dataset\SAresultFormat2E1_E6.xlsx');

%expand data
DatainputNum=size(data,1);
DataNum=DatainputNum*4;

for Datanum=1:DatainputNum
Expandeddata(4*Datanum-3,:)= data(Datanum,:);
Expandeddata(4*Datanum-2,:)= data(Datanum,:);
Expandeddata(4*Datanum-1,:)= data(Datanum,:);
Expandeddata(4*Datanum,:)= data(Datanum,:);
end


inputfeature=Expandeddata(:,1:end-1);  
numofinput=size(inputfeature,1);
for j=1:numofinput
inputfeature1{j,:}=inputfeature(j,:);
end

inputSA=Expandeddata(:,end);    


%% read image data
files = dir(fullfile('F:\dataset\\SeqImageDataE1_E6\\','*.jpg'));
lengthFiles = length(files);

for i = 1:lengthFiles
    
     AA= imread(strcat('F:dataset\SeqImageDataE1_E6\',files(i).name));
I(:,:,:,i)=imresize(AA,[200 200]);
end
inputImage=im2double(I);

%% load label
    [~,Labelstring]=xlsread('F:\dataset\DefectResultsFormat002E1_E6.xlsx');
for labelnum=1:DatainputNum
ImageLabelstring{4*labelnum-3,1} = Labelstring{labelnum, 1};
ImageLabelstring{4*labelnum-2,1} = Labelstring{labelnum, 1};
ImageLabelstring{4*labelnum-1,1} = Labelstring{labelnum, 1};
ImageLabelstring{4*labelnum,1} = Labelstring{labelnum, 1};
end
outputclass=categorical(ImageLabelstring);
classNames = categories(outputclass);

%% Display 20 random training images.
numTrainImages = numel(inputSA);

% figure
% idx = randperm(numTrainImages,20);
% for i = 1:numel(idx)
%     subplot(4,5,i)    
%     imshow(inputImage(:,:,:,idx(i)))
%     title(outputclass(idx(i)))
% end


%% dataset
numTrainImages = numel(inputSA);
radioTest=0.95;
numTest=round((1-radioTest)*numTrainImages);
idxtest = randperm(numTrainImages,numTest);

% file the time property of testdata
idxo=idxtest(find(mod(idxtest+2,2)==1));
idx3test=idxo(find(mod(idxo+3,3)==0));
idx1test=setxor(idxo,idx3test);

idxdtest=idxtest(find(mod(idxtest+2,2)==0));
idx2test=idxdtest(find(mod(idxdtest+4,4)==2));
idx4test=setxor(idxdtest,idx2test);

[~,idxlist1,~] = intersect(idxtest,idx1test);  
[~,idxlist2,~] = intersect(idxtest,idx2test);  
[~,idxlist3,~] = intersect(idxtest,idx3test);  
[~,idxlist4,~] = intersect(idxtest,idx3test);  



%traindata
Testfeature=inputfeature(idxtest,:);
TestImage=inputImage(:,:,:,idxtest);
TestSA=inputSA(idxtest,:);
Testoutputclass=outputclass(idxtest,:);

%testdata
Trainfeature=inputfeature;
TrainImage=inputImage;
TrainSA=inputSA;
Trainoutputclass=outputclass;

Trainfeature(idxtest,:)=[];
TrainImage(:,:,:,idxtest)=[];
TrainSA(idxtest,:)=[];
Trainoutputclass(idxtest,:)=[];
%% Datastore

dsTrainfeature = arrayDatastore(Trainfeature,'IterationDimension',1);
dsTrainImage = arrayDatastore(TrainImage,'IterationDimension',4);
dsTrainSA = arrayDatastore(TrainSA);
dsTrainoutputclass = arrayDatastore(Trainoutputclass);
dsTrain = combine(dsTrainImage,dsTrainfeature,dsTrainoutputclass,dsTrainSA);


% check
% readdsTrainfeature=preview(dsTrainfeature);
% readdsTrainImage=preview(dsTrainImage);
% readdsTrainSA=read(dsTrainSA);
% readdsTrainoutputclass=read(dsTrainoutputclass);

dsTestfeature = arrayDatastore(Testfeature,'IterationDimension',1);
dsTestImage = arrayDatastore(TestImage,'IterationDimension',4);
dsTestSA = arrayDatastore(TestSA);
dsTestoutputclass = arrayDatastore(Testoutputclass);
dsTest = combine(dsTestImage,dsTestfeature,dsTestoutputclass,dsTestSA);


%% Define Deep Learning Model

classes = categories(outputclass);
[h,w,c,numObservations] = size(inputImage);
imageInputSize = [h w c];
numClasses = numel(classes);
numFeatures=size(inputfeature,2);
dim=1;


layers1 = [
    imageInputLayer(imageInputSize,'Normalization','none','Name','in')
    
    convolution2dLayer(10,5,'Stride',4,'Padding',1,'Name','conv1')
    batchNormalizationLayer('Name','bn1')
    maxPooling2dLayer([2 2],'Name','maxpool')
    reluLayer('Name','relu1')
    
    
    convolution2dLayer(5,5,'Stride',2,'Padding','same','Name','conv2')
    batchNormalizationLayer('Name','bn2')
    reluLayer('Name','relu2')
    
    
    convolution2dLayer(3,3,'Padding','same','Name','conv3')
    batchNormalizationLayer('Name','bn3')
    reluLayer('Name','relu4')

    additionLayer(2,'Name','addition')
    fullyConnectedLayer(10,'Name','fc3','WeightL2Factor',0.2)
    
    additionLayer(2,'Name','addition2')
    
    
    fullyConnectedLayer(numClasses,'Name','fc1')
    
    softmaxLayer('Name','softmax')];

lgraph1 = layerGraph(layers1);

layers2 = [
    convolution2dLayer(1,3,'Stride',2,'Name','convSkip')
    batchNormalizationLayer('Name','bnSkip')
    reluLayer('Name','reluSkip')];

lgraph2 = addLayers(lgraph1,layers2);
lgraph2 = connectLayers(lgraph2,'relu1','convSkip');
lgraph2 = connectLayers(lgraph2,'reluSkip','addition/in2');


layers3 = [
    featureInputLayer(numFeatures,'Name','features')
    fullyConnectedLayer(10,'Name','fc4','WeightL2Factor',0.7)
    additionLayer(2,'Name','addition3')
%     concatenationLayer(dim,2,'Name','conc2')
    fullyConnectedLayer(7,'Name','fc5')
    fullyConnectedLayer(1,'Name','fc2');
   ];

lgraph4 = addLayers(lgraph2,layers3);


lgraph5 = connectLayers(lgraph4,'fc4','addition2/in2');


layers6 = [
    fullyConnectedLayer(10,'Name','fc7','WeightL2Factor',0.1)
    softmaxLayer('Name','softmax2')];

lgraph6 = addLayers(lgraph5,layers6);
lgraph6 = connectLayers(lgraph6,'softmax2','addition3/in2');

lgraph6 = connectLayers(lgraph6,'fc3','fc7');

figure
plot(lgraph6)





% deepNetworkDesigner(lgraph)
dlnet = dlnetwork(lgraph6);
dlnet.InputNames


%% Define Model Gradients Function

%% Specify Training Options

numEpochs = 10;
miniBatchSize = 5;

plots = "training-progress";

%% Train Model

mbq = minibatchqueue(dsTrain,...
    'MiniBatchSize',miniBatchSize,...
    'MiniBatchFcn', @preprocessData,...
    'MiniBatchFormat',{'SSCB','BC','',''});% (spatial, spatial, channel, batch)


if plots == "training-progress"
    figure
    lineLossTrain = animatedline('Color',[0.85 0.325 0.098]);
    ylim([0 inf])
    xlabel("Iteration")
    ylabel("Loss")
    grid on
end

%Initialize parameters for Adam.
trailingAvg = [];
trailingAvgSq = [];
lossRecord=[];
%Train the model.
iteration = 0;
start = tic;

% Loop over epochs.

for epoch = 1:numEpochs
    
    % Shuffle data.
    shuffle(mbq)
    
    % Loop over mini-batches
    while hasdata(mbq)
        
        iteration = iteration + 1;
        
        [dlX1,dlX2,dlY1,dlY2] = next(mbq);
                       
        % Evaluate the model gradients, state, and loss using dlfeval and the
        % modelGradients function.
        [gradients,state,loss] = dlfeval(@modelGradients, dlnet,dlX1,dlX2,dlY1,dlY2);
        dlnet.State = state;
        lossRecord=[lossRecord loss];
        % Update the network parameters using the Adam optimizer.
        [dlnet,trailingAvg,trailingAvgSq] = adamupdate(dlnet,gradients, ...
            trailingAvg,trailingAvgSq,iteration);
        
        % Display the training progress.
        if plots == "training-progress"
            D = duration(0,0,toc(start),'Format','hh:mm:ss');
            addpoints(lineLossTrain,iteration,double(gather(extractdata(loss))))
            title("Epoch: " + epoch + ", Elapsed: " + string(D))
            drawnow
        end
    end
end


%% Test Model


mbqTest = minibatchqueue(dsTest,...
    'MiniBatchSize',miniBatchSize,...
    'MiniBatchFcn', @preprocessData,...
    'MiniBatchFormat',{'SSCB','BC','',''});

classesPredictions = [];
anglesPredictions = [];
classCorr = [];
angleDiff = [];
Y1PredBatchRecord=[];
Y1TestRecord=[];
SAPredBatchRecord=[];
SATestRecord=[];


% Loop over mini-batches.
while hasdata(mbqTest)
    
    % Read mini-batch of data.
    [dlX1Test,dlX2Test,dlY1Test,dlY2Test] = next(mbqTest);
    
    % Make predictions using the predict function.
    [dlY1Pred,dlY2Pred] = predict(dlnet,dlX1Test,dlX2Test,'Outputs',["softmax" "fc2"]);
    
    % Determine predicted classes.
    Y1PredBatch = onehotdecode(dlY1Pred,classNames,1);
    classesPredictions = [classesPredictions Y1PredBatch];
    
    % Compare predicted and true classes
    Y1Test = onehotdecode(dlY1Test,classNames,1);
    Y1PredBatchRecord=[Y1PredBatchRecord Y1PredBatch];
    Y1TestRecord=[Y1TestRecord Y1Test];
    classCorr = [classCorr Y1PredBatch == Y1Test];
   
    %plotconfusion(targets,outputs) plots a confusion matrix, using target
    %(true) and output (predicted) labels. Specify the labels as categorical
    %vectors, or in 1-of-N (one-hot) form.
    
    % Dermine predicted angles
    Y2PredBatch = extractdata(dlY2Pred);
    anglesPredictions = [anglesPredictions Y2PredBatch];
    
    % Compare predicted and true angles
    angleDiffBatch = Y2PredBatch - dlY2Test;
    SAPredBatchRecord=[SAPredBatchRecord Y2PredBatch];
    SATestRecord=[SATestRecord dlY2Test];
    angleDiff = [angleDiff extractdata(gather(angleDiffBatch))];
    
end
figure
 plotconfusion(Y1TestRecord,Y1PredBatchRecord)

accuracy = mean(classCorr)

angleRMSE = sqrt(mean(angleDiff.^2))

accuracy1 = mean(classCorr(idxlist1))
accuracy2 = mean(classCorr(idxlist2))
accuracy3 = mean(classCorr(idxlist3))
accuracy4 = mean(classCorr(idxlist4))

angleRMSE1 = sqrt(mean(angleDiff(idxlist1).^2))
angleRMSE2 = sqrt(mean(angleDiff(idxlist2).^2))
angleRMSE3 = sqrt(mean(angleDiff(idxlist3).^2))
angleRMSE4 = sqrt(mean(angleDiff(idxlist4).^2))



save('F:\desktop_work\20220325_MultiInputOutputNN\result\GAF_FE\GAF_FE0112.mat','dlnet','D','accuracy','angleRMSE', ...
    'Y1TestRecord','Y1PredBatchRecord','SAPredBatchRecord','SATestRecord',...
    'TestImage','Testfeature','Testoutputclass','TestSA','idxtest','lossRecord',...
    'accuracy1','accuracy2','accuracy3','accuracy4','angleRMSE1','angleRMSE2','angleRMSE3','angleRMSE4')






%% Model Gradients Function

function [gradients,state,loss] = modelGradients(dlnet,dlX1,dlX2,T1,T2)%combine(dsTestImage,dsTestfeature,dsTestoutputclass,dsTestSA);

[dlY1,dlY2,state] = forward(dlnet,dlX1,dlX2,'Outputs',["softmax" "fc2"]);

fc5weights=abs(dlnet.Layers(23, 1).Weights);
fc1weights=abs(dlnet.Layers(15, 1).Weights);
lossLabels1 = crossentropy(dlY1,T1);
lossAngles2 = mse(dlY2,T2);
L1fc5=sum(sum(fc5weights));
L1fc1=sum(sum(fc1weights));
% lossAngles2=l1loss(dlY2,T2);
loss = lossLabels1 + 0.1*lossAngles2+0.0015*L1fc5+0.001*L1fc1;
gradients = dlgradient(loss,dlnet.Learnables);

end

%% Mini-Batch Preprocessing Function

function [X1,X2,Y,angle] = preprocessData(X1Cell,X2Cell,YCell,angleCell)
    
    % Extract image data from cell and concatenate
    X1 = cat(4,X1Cell{:});

    % Extract feature data from cell and concatenate
    X2 = cat(1,X2Cell{:});

    % Extract label data from cell and concatenate
    Y = cat(2,YCell{:});
    % Extract angle data from cell and concatenate
    angle = cat(2,angleCell{:});
        
    % One-hot encode labels
    Y = onehotencode(Y,1);
    
end


